Mo Language v1.1157.0
==================
Fix: const fn recursive interpreter block boundary.

Key change: gv(K_POS) is the END offset of the current token;
gv(K_TOKPOS) is the START offset. v1.1156 used gv(K_POS) to record
if/else block ends, so recursion entered with position already past
the limit, silently skipping the whole if block (max(7,3) returned 3).

Now block start/end use gv(K_TOKPOS), recursion runs the true branch
from block start with the closing brace as limit.

Gate: 487/0. tests/336_constfn_branch.mo = 142.
Bootstrap: compiler compiles itself to identical md5.

Contents:
- moc: self-hosted Mo compiler (x86_64-linux)
- moc.sig: ED25519 signature (ssh-keygen -Y, namespace mo-release)
- src.tar.gz / src.zip: source of this release
- checksums.txt + .sig: SHA256 of all release assets
- demo/: fib binaries for 4 platforms + signatures

Verify signature:
  cat <file> | ssh-keygen -Y check-novalidate -n mo-release -s <file>.sig
Public key: release/SIGNING_KEY.pub in source tree.
