Mo Language v1.1158.0
==================
const fn can now run real loop code.

New in const fn bodies:
  let n: i64 = expr;        8 locals per invocation frame
  n = expr;  n += e;  -= *= /= %=
  while cond { ... }        nested, mixed with if, may call other const fns

Example (folded entirely at compile time):
  const fn gcd(a: i64, b: i64) -> i64 {
      let x: i64 = a;
      let y: i64 = b;
      let t: i64 = 0;
      while y != 0 { t = x % y; x = y; y = t; }
      return x;
  }

Fixed while implementing:
1. cfn_eval did not restore CFDONE -> a nested const fn call in a loop body
   made the outer interpreter stop after one iteration.
2. Nested call argument frame aliased the caller's parameter frame ->
   'while i <= n' stayed true forever.
3. Compound assignment was silently skipped (wrong result, no error).

Gate: 488/0. tests/337_constfn_loop.mo = 136.
Bootstrap: compiler compiles itself to identical md5.

Contents:
- moc: self-hosted Mo compiler (x86_64-linux)
- moc.sig: ED25519 signature (ssh-keygen -Y, namespace mo-release)
- src.tar.gz / src.zip: source of this release
- checksums.txt + .sig: SHA256 of all release assets
- demo/: fib binaries for 4 platforms + signatures, constfn.mo source

Verify signature:
  cat <file> | ssh-keygen -Y check-novalidate -n mo-release -s <file>.sig
Public key: release/SIGNING_KEY.pub in source tree.
