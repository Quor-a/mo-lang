import "io.mo";
# v1.1158: const fn 循环 —— 全部在编译期折叠
const fn sum_to(n: i64) -> i64 {
    let s: i64 = 0;
    let i: i64 = 1;
    while i <= n { s = s + i; i = i + 1; }
    return s;
}
const fn fact(n: i64) -> i64 {
    let r: i64 = 1;
    let i: i64 = 2;
    while i <= n { r *= i; i += 1; }
    return r;
}
const fn gcd(a: i64, b: i64) -> i64 {
    let x: i64 = a;
    let y: i64 = b;
    let t: i64 = 0;
    while y != 0 { t = x % y; x = y; y = t; }
    return x;
}
fn main() -> i64 {
    print_i64(sum_to(10));
    print(" ");
    print_i64(fact(5));
    print(" ");
    print_i64(gcd(48, 18));
    print("\n");
    return 0;
}
